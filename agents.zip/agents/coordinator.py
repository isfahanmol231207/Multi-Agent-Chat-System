from .research_agent import ResearchAgent
from .analysis_agent import AnalysisAgent
from .memory_agent import MemoryAgent

class Coordinator:
    def __init__(self):
        self.name = "Coordinator"   # ✅ FIX IS HERE
        self.research_agent = ResearchAgent()
        self.analysis_agent = AnalysisAgent()
        self.memory_agent = MemoryAgent()

    def decompose_and_route(self, user_query: str):
        query_lower = user_query.lower()

        if any(keyword in query_lower for keyword in ["what did we learn", "earlier"]):
            return ["MEMORY_RETRIEVE"]

        elif any(keyword in query_lower for keyword in ["analyze", "compare", "trade-offs", "efficiency"]):
            return ["RESEARCH", "ANALYZE", "MEMORY_STORE"]

        elif "what are" in query_lower or "find information" in query_lower:
            return ["RESEARCH", "MEMORY_STORE"]

        else:
            return ["RESEARCH"]

    def process_query(self, user_query: str):
        print(f"\n--- Coordinator received query: '{user_query}' ---")

        plan = self.decompose_and_route(user_query)
        current_data = user_query
        final_answer = ""

        for step in plan:
            print(f"Coordinator routing task to: {step}")

            if step == "RESEARCH":
                result = self.research_agent.research(current_data)
                final_answer = result["content"]
                current_data = final_answer

            elif step == "ANALYZE":
                result = self.analysis_agent.analyze(current_data, user_query)
                final_answer = result["result"]
                current_data = final_answer

            elif step == "MEMORY_RETRIEVE":
                result = self.memory_agent.handle_request({
                    "action": "RETRIEVE_CONTEXT",
                    "payload": {"query": user_query}
                })
                final_answer = result["data"]

            elif step == "MEMORY_STORE":
                self.memory_agent.handle_request({
                    "action": "STORE_FINDING",
                    "payload": {
                        "content": final_answer,
                        "topic": user_query[:30],
                        "agent": self.name,
                        "confidence": 0.9
                    }
                })

        print("--- Coordinator finished plan ---")
        return final_answer
