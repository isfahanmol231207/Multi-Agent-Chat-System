class AnalysisAgent:
    def __init__(self):
        self.name = "AnalysisAgent"

    def analyze(self, data, original_query):
        print("[AnalysisAgent] Analyzing research data")
        return {
            "result": f"Analysis based on: {data}",
            "confidence": 0.8
        }
