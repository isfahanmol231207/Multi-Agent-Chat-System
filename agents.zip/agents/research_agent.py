class ResearchAgent:
    def __init__(self):
        self.name = "ResearchAgent"

    def research(self, query):
        print(f"[ResearchAgent] Researching: {query}")
        return {
            "content": f"Basic information about {query}",
            "confidence": 0.7
        }
