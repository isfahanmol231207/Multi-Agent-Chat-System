import datetime

class MemoryAgent:
    def __init__(self):
        self.memory = []

    def handle_request(self, request):
        action = request["action"]
        payload = request["payload"]

        if action == "STORE_FINDING":
            record = {
                "content": payload["content"],
                "topic": payload["topic"],
                "agent": payload["agent"],
                "confidence": payload["confidence"],
                "timestamp": str(datetime.datetime.now())
            }
            self.memory.append(record)
            print("[MemoryAgent] Stored finding in memory")
            return {"status": "stored", "data": record}

        elif action == "RETRIEVE_CONTEXT":
            query = payload["query"].lower()
            for record in self.memory:
                if query in record["content"].lower():
                    print("[MemoryAgent] Retrieved matching memory")
                    return {"status": "found", "data": record["content"]}
            return {"status": "empty", "data": "No relevant memory found"}

        return {"status": "error", "data": "Unknown action"}
