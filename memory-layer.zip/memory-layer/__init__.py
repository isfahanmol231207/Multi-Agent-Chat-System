class Coordinator:
    def __init__(self):
        self.name = "Coordinator"   # ✅ ADD THIS LINE
        self.research_agent = ResearchAgent()
        self.analysis_agent = AnalysisAgent()
        self.memory_agent = MemoryAgent()
